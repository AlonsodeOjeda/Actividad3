import React from "react";

export const ErrorPagina = ()=>{
    return(
    <div>
        <h1>Página no encontrada</h1>
    </div>
    );
};